# Nexxie Website

## Instructions to Run the Website Template

1. Download and extract the zip file.
2. Open PowerShell and navigate to the path where you saved the project (e.g., `cd Users/Desktop/Nexxie`).
3. Run the project using the following command:
    ```
    npm run dev
    ```
    If the project doesn't start, press `o` and then `Enter` to open it in your browser.



## Directory Structure
Nexxie/
    public/
        favicon-32x32.png
    src/
        App.css
        App.jsx
        main.jsx
        NavMenu.jsx
        News.jsx
        assets/
            icon-menu.svg
            icon-menu-close.svg
            image-gaming-growth.jpg
            image-retro-pcs.jpg
            image-top-laptops.jpg
            image-web-3-desktop.jpg
            image-web-3-mobile.jpg
            logo.svg
    index.html




