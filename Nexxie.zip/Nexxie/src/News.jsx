import React, { useEffect, useState } from 'react';

/**
*  News
*
*  @author Alexantros Tamboutsiaris
*/

const News = () => {
    const [articles, setArticles] = useState([]);

    useEffect(() => {
        fetch('https://6380ce5a786e112fe1ba951e.mockapi.io/Articles')
            .then(response => response.json())
            .then(data => setArticles(data.slice(0, 3))) // Get the first 3 items
            .catch(error => console.error('Error fetching articles:', error));
    }, []);

    return (
        <aside className="news">
            <h3>New</h3>
            <ul>
                {articles.map((article, index) => (
                    <li key={index}>
                        <a href={'#' + article.id}>{article.title}</a>
                        <p>{article.description}</p>
                        {index < articles.length - 1 && <hr />}
                    </li>
                ))}
            </ul>
        </aside>
    );
};

export default News;
