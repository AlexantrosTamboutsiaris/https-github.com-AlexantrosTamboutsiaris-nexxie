import React, { useState } from 'react';
import './App.css';
import NavMenu from './NavMenu';
import News from './News';
import logo from './assets/logo.svg';
import imageWeb3Desktop from './assets/image-web-3-desktop.jpg';
import imageWeb3Mobile from './assets/image-web-3-mobile.jpg';
import imageTopLaptops from './assets/image-top-laptops.jpg';
import imageRetroPCs from './assets/image-retro-pcs.jpg';
import imageGamingGrowth from './assets/image-gaming-growth.jpg';

/**
*  App
*
*  @author Alexantros Tamboutsiaris
*/

function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} alt="W." className="App-logo" />
        <NavMenu isOpen={menuOpen} toggleMenu={toggleMenu} />
      </header>

      <div className="Element1">
        <section className="highlight">
          <picture>
            <source srcSet={imageWeb3Mobile} media="(max-width: 375px)" />
            <img src={imageWeb3Desktop} alt="highlight" className="highlight-img" />
          </picture>
          <div className="highlight-text">
            <h2>The Bright Future of Web 3.0?</h2>
            <div>
              <p>
                We dive into the next evolution of the web that claims to put the power of the platforms back into the hands of the people. But is it really fulfilling its promise?
              </p>
              <button>READ MORE</button>
            </div>
          </div>
        </section>
        <News />
      </div>

      <div className="Element2">
        <section className="articles">
          <article>
            <img src={imageRetroPCs} alt="Reviving Retro PCs" />
            <div className="article-text">
              <span className="article-number">01</span>
              <div>
                <a href="#reviving-retro-pcs">Reviving Retro PCs</a>
                <p>What happens when old PCs are given modern upgrades?</p>
              </div>
            </div>
          </article>
          <article>
            <img src={imageTopLaptops} alt="Top 10 Laptops of 2022" />
            <div className="article-text">
              <span className="article-number">02</span>
              <div>
                <a href="#top-10-laptops">Top 10 Laptops of 2022</a>
                <p>Our best picks for various needs and budgets.</p>
              </div>
            </div>
          </article>
          <article>
            <img src={imageGamingGrowth} alt="The Growth of Gaming" />
            <div className="article-text">
              <span className="article-number">03</span>
              <div>
                <a href="#growth-of-gaming">The Growth of Gaming</a>
                <p>How the pandemic has sparked fresh opportunities.</p>
              </div>
            </div>
          </article>
        </section>
      </div>
    </div>
  );
}

export default App;
