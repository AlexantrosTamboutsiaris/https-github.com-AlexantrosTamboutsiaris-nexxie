import React from 'react';
import './App.css';
import menuIcon from './assets/icon-menu.svg';
import closeIcon from './assets/icon-menu-close.svg';

/**
*  NavNenu
*
*  @author Alexantros Tamboutsiaris
*/

const NavMenu = ({ isOpen, toggleMenu }) => {
    return (
        <div>
            <nav className={'App-nav' + (isOpen ? ' open' : '')}>
                <a href="#home">Home</a>
                <a href="#new">New</a>
                <a href="#popular">Popular</a>
                <a href="#trending">Trending</a>
                <a href="#categories">Categories</a>
            </nav>
            <button className="menu-button" onClick={toggleMenu}>
                <img src={isOpen ? closeIcon : menuIcon} alt="Menu Icon" />
            </button>
        </div>
    );
};

export default NavMenu;

